import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/shared/employee.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})

export class EmployeeComponent implements OnInit {

  profileForm = this.fb.group({
    UserName: ['', Validators.required],
    email: [''],
      phone: [''],
      gender: [''],
      age: ['']
    });

  constructor(private service: EmployeeService,
    private toastr: ToastrService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)     //if new data is there
    //if(form)
      form.resetForm();
    this.service.formData2 = {
      id: '',
      userName: '',
      email: '',
      phone: null,
      gender: '',
      age: null
    }
  }

  onSubmit(form: NgForm) {
    if (form.value.id =="" )
    // if (form.value.userName == null)
      this.insertRecord(form);
    //else (this.updateRecord(form))
    else(this.insertRecord(form))
      // this.updateRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postEmployee(form.value).subscribe(res => {
      console.log(form.value)
      this.toastr.success('Inserted successfully', 'EMP2. Register');
      this.resetForm(form);
      this.service.refreshList();
    });
  }
  
  updateRecord(form: NgForm) {
    this.service.putEmployee(form.value).subscribe(res => {
      this.toastr.info('Updated successfully', 'EMP. Register');
      console.log(form.value)
      this.resetForm(form);
      this.service.refreshList();
    });
  }
  onSubmit2() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
    console.log(this.profileForm.value);
  }

}
