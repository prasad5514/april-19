// export class Employee {
//     EmployeeID: number;
//     FullName: string;
//     EMPCode: string;
//     Mobile: string;
//     Position: string;
// }

export class Employee {
    // _id: string;
    EmployeeID: number;
    FullName: string;
    EMPCode: string;
    Mobile: string;
    Position: string;
}
