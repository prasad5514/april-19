import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/shared/employee.service';
import { Employee } from 'src/app/shared/employee.model';
import { EmployeeC } from './employee.modelFi';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private service: EmployeeService,
    private toastr: ToastrService) { }
    empModV:EmployeeC[];

  ngOnInit() {
    this.service.refreshList();
    // this.service.refreshList().subscribe((data3)=>{
    //   this.empModV=JSON.parse(JSON.stringify(data3))
    // })
  }

  populateForm(emp: EmployeeC) {
    this.service.formData2 = Object.assign({}, emp); 
    //this.toastr.warning(this.service.formData2.email);
    //alert(this.service.formData2.email)
    //EmpModV=this.service.formData2;
  
  }

  onDelete(id: number) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteEmployee(id).subscribe(res => {
        this.service.refreshList();
        this.toastr.warning('Deleted successfully', 'EMP1. Register');
      });
    }
  }

}
