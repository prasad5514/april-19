// export class Employee {
//     EmployeeID: number;
//     FullName: string;
//     EMPCode: string;
//     Mobile: string;
//     Position: string;
// }

export class EmployeeC {
    //id: number;
    //EmployeeID: number;
    id: string;
    userName: string;
    email: string;
    phone: number;
    gender: string;
    age: number;
}
