import { Injectable } from '@angular/core';
//import { Employee } from './employee.model';
import { EmployeeC } from '../employees/employee-list/employee.modelFi';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  // formData  : Employee;
  // list : Employee[];
  formData2 : EmployeeC;
  list2 : EmployeeC[];
  //readonly rootURL ="http://localhost:7741/api"
  readonly rootURL2 ="https://dev.digisuvidhacentre.com/Profile/api/MockUser"

  constructor(private http : HttpClient) { }

  //postEmployee(formData2 : EmployeeC){
    postEmployee(formData2: EmployeeC){
      //postEmployee(){
    //return this.http.post(this.rootURL3,this.list2);
    return this.http.post(this.rootURL2,formData2)

  // return this.http.post(this.rootURL2,{"UserName": "Demo user",
  //   "Email": "demomail@mail.com",
  //   "Phone": "1234567890",
  //   "Gender": "M",
  //   "Age": 28
  //  }
    
  }

  refreshList(){
    //this.http.get(this.rootURL2+'/EmployeeC')
    //this.http.get(this.rootURL2)
    this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
    .toPromise().then(res => this.list2 = res as EmployeeC[]);
    //return this.http.get(this.rootURL2);
  }

  putEmployee(formData2 : EmployeeC){
    // return this.http.put(this.rootURL2+'/EmployeeC/'+formData2.EmployeeID,formData2);
    // return this.http.put(this.rootURL2+'/EmployeeC/'+formData2.id,formData2);
    return this.http.put(this.rootURL2,formData2)
     
   }

   deleteEmployee(id : number){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    return this.http.delete(this.rootURL2+'/Delete/'+id);
   }

}
